
from pydantic import BaseModel, Field, field_validator, model_validator, ValidationError

class Prompt(BaseModel):
    prompt: str = Field()
    fn_name: str = None
    args: dict(str: str|int|float|bool) = None